notes:

1. The ability to correct the content will only be shown if there are suggestions available for that current word.

2. The ability to write the corrected text or content to a file will only be prompted if there are at least one suggestion available for an incorrect word

3. The program will loop through the file line by line to allow the user to correct each line, at the end will prompt the final corrected content. If
the user wants to overwrite the old content with the new one simply input the old file's name.

4. Suggestions that the program made may be a lot so it is recommended that the terminal inside intellij should be expanded.